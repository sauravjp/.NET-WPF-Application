﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace FinalSauravPatel
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private LawFirmDBEntities1 dbContext = new LawFirmDBEntities1();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadAttorneysComboBox();
            LoadBillingDataGrid();
        }
        private void LoadAttorneysComboBox()
        {
            var attorneys = dbContext.Attorneys.Select(a => a.LastName).ToList();
            cmb_Attorneys.ItemsSource = attorneys;
        }

        private void LoadBillingDataGrid()
        {
            var billingData = dbContext.Billings.ToList();
            DataGrid_Billings.ItemsSource = billingData;
        }
        private void cmb_Attorneys_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedAttorneyLastName = (string)cmb_Attorneys.SelectedItem;
            var billingData = dbContext.Billings.Where(b => b.Attorney.LastName == selectedAttorneyLastName).ToList();
            DataGrid_Billings.ItemsSource = billingData;
        }

        private void btn_Clients_Click(object sender, RoutedEventArgs e)
        {
            string searchKeyword = txt_Clients.Text;
            var clientsData = dbContext.Clients.Where(c => c.FirstName.Contains(searchKeyword) || c.LastName.Contains(searchKeyword)).ToList();

            if (clientsData.Count == 0)
            {
                MessageBox.Show("Name not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                ClearFields();
            }
            else
            {
                DataGrid_Billings.ItemsSource = clientsData;

            }
        }

        private void btn_Billid_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txt_Billid.Text))
            {
                int billId = int.Parse(txt_Billid.Text);
                var billing = dbContext.Billings.FirstOrDefault(b => b.BillingID == billId);
                if (billing != null)
                {
                    txt_Client.Text = $"{billing.Client.FirstName} {billing.Client.LastName}";
                    txt_Category.Text = billing.Category.Category1;
                    txt_Attorney.Text = $"{billing.Attorney.FirstName} {billing.Attorney.LastName}";
                    txt_Fees.Text = (billing.Hours * (double)billing.Rate.Rate1).ToString();
                }
                else
                {
                    MessageBox.Show("Bill not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    ClearFields();
                }
            }
            else
            {
                MessageBox.Show("Please enter a Bill ID.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btn_GetAllBills_Click(object sender, RoutedEventArgs e)
        {
            LoadBillingDataGrid();
        }

        private void btn_ClearFields_Click(object sender, RoutedEventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txt_Billid.Text = string.Empty;
            txt_Client.Text = string.Empty;
            txt_Category.Text = string.Empty;
            txt_Attorney.Text = string.Empty;
            txt_Fees.Text = string.Empty;
            txt_Clients.Text = "";

            DataGrid_Billings.Columns.Clear();
            DataGrid_Billings.ItemsSource = null;

            cmb_Attorneys.SelectedIndex = -1;

        }
    }
}
